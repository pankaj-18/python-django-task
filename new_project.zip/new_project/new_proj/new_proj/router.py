from Customers.api.viewsets import CustomersviewSets
from rest_framework import routers
router=routers.DefaultRouter()
router.register('Customers',CustomersviewSets)