from django.contrib import admin
from .models import Users,Customers
# Register your models here.
@admin.register(Users)
class UsersModelAdmin(admin.ModelAdmin):
    list_display = ['id','first_name','last_name','email','mobile']

@admin.register(Customers)
class CustomersModelAdmin(admin.ModelAdmin):
    list_display = ['profile_number']


def site():
    return None