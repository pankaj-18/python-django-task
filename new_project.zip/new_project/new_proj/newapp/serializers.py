from rest_framework import serializers

# import model from models.py
from .models import Customers

# Create a model serializer
class CustomersSerializer(serializers.HyperlinkedModelSerializer):
	class Meta:
		model = Customers
		fields = ('profile_number')
