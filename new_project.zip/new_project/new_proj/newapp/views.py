from django.shortcuts import render

from .models import Customers
from .serializers import CustomersSerializer
from rest_framework import viewsets

class CustomersviewSets(viewsets.ModelViewSet):
    queryset = Customers.objects.all()
    serializer_class = CustomersSerializer

def home(request):
    return render(request,'home.html')