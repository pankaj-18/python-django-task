# basic URL Configurations
from django.urls import include, path
# import routers
from rest_framework import routers

# import everything from views
from . import  views
from .views import *

# define the router
router = routers.DefaultRouter()

# define the router path and viewset to be used
router.register('Customers', CustomersviewSets)

# specify URL Path for rest_framework
urlpatterns = [
	path('', include(router.urls)),
	path('api/', include('rest_framework.urls')),
	path('',views.home,name='home')

]
